async function carregarSite(){
  const resp=await fetch("/api/site");
  const data=await resp.json();

  document.title=data.club.name;
  slogan.textContent=data.club.slogan.toUpperCase();
  description.textContent=data.club.description;
  eventTitle.textContent=data.event.title;
  eventDate.textContent=data.event.date;
  eventTime.textContent=data.event.time;
  eventPlace.textContent=data.event.place;
  eventDescription.textContent=data.event.description;
  city.textContent=data.club.city;

  const msg=encodeURIComponent("Olá, quero comprar ingresso para "+data.event.title);
  const whats="https://wa.me/"+data.club.whatsapp+"?text="+msg;
  whatsappHero.href=whats;
  whatsappFooter.href=whats;

  ticketGrid.innerHTML="";
  data.tickets.forEach(ticket=>{
    const texto=encodeURIComponent(`Olá, quero comprar ingresso ${ticket.name} da ${data.club.name}. Valor R$ ${ticket.price}`);
    const link=`https://wa.me/${data.club.whatsapp}?text=${texto}`;
    ticketGrid.innerHTML+=`
      <article class="ticket">
        <h3>${ticket.name}</h3>
        <p>${ticket.description}</p>
        <strong class="price">R$ ${ticket.price}</strong>
        <a class="btn" href="${link}">Comprar</a>
      </article>`;
  });
}
carregarSite();
